# Aura Bits (Android)

The Android app is a WebView wrapper around the Aura Bits prototype. The page lives in `app/src/main/assets/index.html`, and all data stays in the phone's local storage.

## Build the APK on GitHub

1. Create a new GitHub repository and push this folder to it.
2. Go to the **Actions** tab. The "Build APK" workflow runs on every push to `main`, or you can run it manually with **Run workflow**.
3. When it finishes, open the run and download the `aura-bits-debug-apk` artifact. It contains `app-debug.apk`.
4. Copy the APK to your phone, allow installs from unknown sources, and install it.

## Updating the app

Replace `app/src/main/assets/index.html` with a new version and push. The workflow builds a new APK.
